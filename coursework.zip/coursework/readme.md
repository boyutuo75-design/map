# Coursework: Autonomous Treasure Hunt Robot (ROS2 Humble + TurtleBot3)

This coursework implements an autonomous treasure-hunt robot system using ROS2 Humble, TurtleBot3, and Gazebo.  
The robot explores a known environment, detects red fire hydrants and green trash cans, approaches objects safely, and marks their positions in RViz.

**Modules implemented include:**
- Color-based object detection (OpenCV)
- AMCL localization
- Multi-point exploration
- Object approach using Nav2 navigation
- RViz marker visualization
- Modular ROS2 node architecture

---

## 📦 Package Structure

coursework/
├── package.xml
├── setup.py
├── README.md
├── resource/
│ └── coursework
├── launch/
│ └── robot_search.launch.py
└── coursework/
├── init.py
├── main_controller.py
├── color_detector.py
├── marker_publisher.py
├── pose_listener.py
├── explorer_node.py
├── navigator.py
└── utils.py