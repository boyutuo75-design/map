#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Marker Publisher (with object_localizer)

职责：
- 订阅：
    /object_position (PointStamped, in map frame)
    /mark_object     (String, "red"/"green")
- 使用最新的 object_position 在 RViz 中发布 Marker
"""

import rclpy
from rclpy.node import Node

from std_msgs.msg import String
from geometry_msgs.msg import PointStamped
from visualization_msgs.msg import Marker
from builtin_interfaces.msg import Duration


class MarkerPublisher(Node):

    def __init__(self):
        super().__init__('marker_publisher')

        self.declare_parameter('map_frame', 'map')
        self.map_frame = self.get_parameter('map_frame').value

        # 最新的物体位置
        self.last_object_position: PointStamped | None = None

        # 订阅 object_localizer 提供的物体位置
        self.obj_sub = self.create_subscription(
            PointStamped,
            'object_position',
            self.on_object_position,
            10
        )

        # 订阅 main_controller 的标记命令（只含颜色）
        self.mark_sub = self.create_subscription(
            String,
            'mark_object',
            self.on_mark_request,
            10
        )

        # Marker publisher
        self.marker_pub = self.create_publisher(Marker, 'visualization_marker', 10)

        self.marker_id = 0

        self.get_logger().info("MarkerPublisher initialised (using object_position).")

    # ----------------- 缓存物体位置 ----------------- #

    def on_object_position(self, msg: PointStamped):
        self.last_object_position = msg

    # ----------------- 收到标记命令 ----------------- #

    def on_mark_request(self, msg: String):
        color = msg.data

        if self.last_object_position is None:
            self.get_logger().warn("Mark request received but no object_position available.")
            return

        marker = self.create_marker_template(color)

        marker.pose.position.x = self.last_object_position.point.x
        marker.pose.position.y = self.last_object_position.point.y
        marker.pose.position.z = 0.1

        self.marker_pub.publish(marker)

        self.get_logger().info(
            f"Marker #{marker.id} for {color} at "
            f"x={marker.pose.position.x:.2f}, "
            f"y={marker.pose.position.y:.2f}"
        )

    # ----------------- 创建 marker 模板 ----------------- #

    def create_marker_template(self, color: str) -> Marker:
        marker = Marker()
        marker.header.frame_id = self.map_frame
        marker.header.stamp = self.get_clock().now().to_msg()

        marker.type = Marker.SPHERE
        marker.action = Marker.ADD

        marker.lifetime = Duration(sec=0)

        marker.scale.x = 0.25
        marker.scale.y = 0.25
        marker.scale.z = 0.25

        if color == 'red':
            marker.color.r = 1.0
            marker.color.g = 0.0
            marker.color.b = 0.0
        elif color == 'green':
            marker.color.r = 0.0
            marker.color.g = 1.0
            marker.color.b = 0.0
        else:
            marker.color.r = 1.0
            marker.color.g = 1.0
            marker.color.b = 1.0
        marker.color.a = 1.0

        marker.id = self.marker_id
        self.marker_id += 1

        marker.pose.orientation.w = 1.0

        return marker


def main(args=None):
    rclpy.init(args=args)
    node = MarkerPublisher()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    node.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()
