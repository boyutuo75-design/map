#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
导航客户端节点（Navigator Node）

职责:
- 接收 main_controller 的导航目标 PoseStamped
- 调用 Nav2 NavigateToPose Action 完成导航
- 发布导航状态（idle, running, succeeded, failed）
"""

import rclpy
from rclpy.node import Node
from rclpy.action import ActionClient

from nav2_msgs.action import NavigateToPose
from geometry_msgs.msg import PoseStamped
from std_msgs.msg import String


class Navigator(Node):

    def __init__(self):
        super().__init__('navigator')

        # Action Client → Nav2
        self.nav_action_client = ActionClient(self, NavigateToPose, 'navigate_to_pose')

        # Publisher → main_controller
        self.nav_status_pub = self.create_publisher(String, 'nav_status', 10)

        # Subscriber ← main_controller
        self.goal_sub = self.create_subscription(
            PoseStamped,
            'nav_goal',
            self.on_goal_received,
            10
        )

        # 当前 action 的句柄
        self._goal_handle = None
        self._sending_goal_future = None
        self._result_future = None

        # 内部状态
        self.navigation_active = False

        self.get_logger().info("Navigator initialized and ready.")

    # ====================================================================== #
    #                         接收导航目标（核心）                            #
    # ====================================================================== #

    def on_goal_received(self, goal_msg: PoseStamped):
        """收到 main_controller 发布的导航目标"""

        # ---------------------- 特判：空目标 → 取消导航 ---------------------- #
        if goal_msg.pose.position.x == 0.0 and goal_msg.pose.position.y == 0.0:
            self.get_logger().info("Received STOP signal → Canceling navigation.")
            self.cancel_navigation()
            return

        # ------------------------------------------------------------------- #

        self.get_logger().info(
            f"Received goal: ({goal_msg.pose.position.x:.2f}, {goal_msg.pose.position.y:.2f})"
        )

        # 等待 Nav2 Action Server
        if not self.nav_action_client.wait_for_server(timeout_sec=2.0):
            self.get_logger().error("Nav2 action server not available.")
            self.publish_status("failed")
            return

        # 构造导航目标
        goal = NavigateToPose.Goal()
        goal.pose = goal_msg

        # 向 Nav2 发送 goal
        self._sending_goal_future = self.nav_action_client.send_goal_async(
            goal,
            feedback_callback=self.navigation_feedback_callback
        )
        self._sending_goal_future.add_done_callback(self.navigation_goal_response_callback)

        self.navigation_active = True
        self.publish_status("running")

    # ====================================================================== #
    #                 Nav2 回调：目标是否被接受（GoalResponse）               #
    # ====================================================================== #

    def navigation_goal_response_callback(self, future):
        """Nav2 是否接受目标"""

        self._goal_handle = future.result()

        if not self._goal_handle.accepted:
            self.get_logger().warn("Nav2 rejected the goal.")
            self.publish_status("failed")
            self.navigation_active = False
            return

        self.get_logger().info("Nav2 accepted goal. Navigating...")

        # 等待导航结束
        self._result_future = self._goal_handle.get_result_async()
        self._result_future.add_done_callback(self.navigation_result_callback)

    # ====================================================================== #
    #                     Nav2 回调：导航完成（Result）                        #
    # ====================================================================== #

    def navigation_result_callback(self, future):
        """导航完成时调用"""

        status = future.result().status
        self.navigation_active = False

        if status == 4:  # STATUS_SUCCEEDED
            self.publish_status("succeeded")
            self.get_logger().info("Navigation succeeded.")

        elif status == 5:  # STATUS_ABORTED
            self.publish_status("failed")
            self.get_logger().warn("Navigation aborted.")

        elif status == 6:  # STATUS_CANCELED
            self.publish_status("failed")
            self.get_logger().warn("Navigation canceled.")

        else:
            self.publish_status("failed")
            self.get_logger().warn(f"Navigation finished with status = {status}")

    # ====================================================================== #
    #                             导航反馈                                    #
    # ====================================================================== #

    def navigation_feedback_callback(self, feedback_msg):
        """可选：你可在这里打印机器人的当前导航过程"""
        # feedback = feedback_msg.feedback
        pass

    # ====================================================================== #
    #                           取消导航功能                                  #
    # ====================================================================== #

    def cancel_navigation(self):
        """取消当前导航"""
        if self._goal_handle is not None:
            cancel_future = self._goal_handle.cancel_goal_async()
            cancel_future.add_done_callback(lambda _: self.publish_status("failed"))

        self.navigation_active = False

    # ====================================================================== #
    #                        发布状态给 main_controller                       #
    # ====================================================================== #

    def publish_status(self, status: str):
        msg = String()
        msg.data = status
        self.nav_status_pub.publish(msg)


# ====================================================================== #
#                                    main                                 #
# ====================================================================== #

def main(args=None):
    rclpy.init(args=args)
    node = Navigator()

    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass

    node.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()
