#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Main Controller (Setup.py Compatible Version)
不使用 .srv 文件，完全依赖标准 Topic 通信。
"""

import rclpy
from rclpy.node import Node
import math

from std_msgs.msg import String, Empty
from geometry_msgs.msg import PoseStamped, PointStamped

class RobotState:
    IDLE = 'IDLE'
    EXPLORING = 'EXPLORING'
    OBJECT_DETECTED = 'OBJECT_DETECTED'
    MARKING = 'MARKING'
    FINISHED = 'FINISHED'

class MainController(Node):

    def __init__(self) -> None:
        super().__init__('main_controller')

        self.state = RobotState.IDLE
        self.last_detected_color = 'none'
        self.navigation_active = False

        # 记忆模块
        self.found_objects = []
        self.min_duplicate_dist = 1.0
        self.last_object_position: PointStamped | None = None

        self.declare_parameter('max_run_time', 300.0)
        self.max_run_time = float(self.get_parameter('max_run_time').value)
        self.start_time = self.get_clock().now()

        # === 修改点：使用 Topic 通信替代 Service ===
        # 1. 发布请求：告诉 Explorer "我需要个新点"
        self.request_goal_pub = self.create_publisher(Empty, '/request_explore_goal', 10)

        # 2. 订阅结果：接收 Explorer 发回来的点
        self.goal_result_sub = self.create_subscription(
            PoseStamped,
            '/explore_goal_result',
            self.on_new_explore_goal,
            10
        )
        # =========================================

        self.nav_goal_pub = self.create_publisher(PoseStamped, 'nav_goal', 10)

        self.nav_status_sub = self.create_subscription(String, 'nav_status', self.on_nav_status, 10)
        self.color_sub = self.create_subscription(String, 'detected_color', self.on_color_detected, 10)
        self.object_pos_sub = self.create_subscription(PointStamped, 'object_position', self.on_object_position, 10)
        self.mark_pub = self.create_publisher(String, 'mark_object', 10)

        # 标志位：防止一直发请求
        self.waiting_for_goal = False

        self.control_timer = self.create_timer(0.1, self.control_loop)
        self.get_logger().info("MainController (No-Service Mode) Started.")

    # ----------------- 收到新目标的回调 ----------------- #
    def on_new_explore_goal(self, msg: PoseStamped):
        """当 ExplorerNode 发回坐标时触发"""
        if self.state == RobotState.EXPLORING:
            self.get_logger().info(f"Received new goal: ({msg.pose.position.x:.2f}, {msg.pose.position.y:.2f})")
            self.nav_goal_pub.publish(msg)
            self.navigation_active = True
            self.waiting_for_goal = False

    # ----------------- 辅助逻辑 ----------------- #
    def is_duplicate(self, new_pos: PointStamped, color: str) -> bool:
        if new_pos is None: return False
        for obj in self.found_objects:
            dist = math.sqrt((new_pos.point.x - obj['x'])**2 + (new_pos.point.y - obj['y'])**2)
            if dist < self.min_duplicate_dist and color == obj['type']:
                return True
        return False

    def on_nav_status(self, msg: String):
        if msg.data == "running":
            self.navigation_active = True
        elif msg.data in ["succeeded", "failed"]:
            self.navigation_active = False
            self.waiting_for_goal = False # 允许请求下一个点

    def on_color_detected(self, msg: String):
        if self.state == RobotState.EXPLORING and msg.data in ["red", "green"]:
            if self.last_object_position and not self.is_duplicate(self.last_object_position, msg.data):
                self.last_detected_color = msg.data
                self.state = RobotState.OBJECT_DETECTED

    def on_object_position(self, msg: PointStamped):
        self.last_object_position = msg

    # ----------------- 核心循环 ----------------- #
    def control_loop(self):
        elapsed = (self.get_clock().now() - self.start_time).nanoseconds * 1e-9
        if elapsed > self.max_run_time and self.state != RobotState.FINISHED:
            self.state = RobotState.FINISHED

        if self.state == RobotState.IDLE:
            self.state = RobotState.EXPLORING

        elif self.state == RobotState.EXPLORING:
            # 如果没在导航，也没在等回复，就发请求
            if not self.navigation_active and not self.waiting_for_goal:
                self.get_logger().info("Requesting new random goal...")
                self.request_goal_pub.publish(Empty())
                self.waiting_for_goal = True

        elif self.state == RobotState.OBJECT_DETECTED:
            # 发送停止
            stop_goal = PoseStamped()
            stop_goal.header.frame_id = "map"
            stop_goal.pose.orientation.w = 1.0
            self.nav_goal_pub.publish(stop_goal)

            self.navigation_active = False
            self.waiting_for_goal = False
            self.state = RobotState.MARKING

        elif self.state == RobotState.MARKING:
            if self.last_detected_color in ["red", "green"] and self.last_object_position:
                self.found_objects.append({
                    'x': self.last_object_position.point.x,
                    'y': self.last_object_position.point.y,
                    'type': self.last_detected_color
                })
                # 发布标记
                msg = String()
                msg.data = self.last_detected_color
                self.mark_pub.publish(msg)
                self.get_logger().info(f"Marked {self.last_detected_color}.")

            self.state = RobotState.EXPLORING
            self.last_detected_color = 'none'

        elif self.state == RobotState.FINISHED:
            if self.navigation_active:
                stop_goal = PoseStamped()
                stop_goal.header.frame_id = "map"
                self.nav_goal_pub.publish(stop_goal)
            self.navigation_active = False
            rclpy.shutdown()

def main(args=None):
    rclpy.init(args=args)
    rclpy.spin(MainController())
    rclpy.shutdown()