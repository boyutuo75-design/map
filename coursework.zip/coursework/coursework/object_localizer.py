#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Object Localizer Node

职责：
- 使用 RGB + Depth + CameraInfo + TF2
- 检测 red / green 物体
- 在 map 坐标系下估计物体位置
- 发布：
    /detected_color  (String: "red"/"green"/"none")
    /object_position (PointStamped in frame "map")
"""

import math
import numpy as np
import cv2
import pyrealsense2 as rs

import rclpy
from rclpy.node import Node
from rclpy.time import Time

from sensor_msgs.msg import Image, CameraInfo
from std_msgs.msg import String
from geometry_msgs.msg import PointStamped
from cv_bridge import CvBridge

from tf2_ros import Buffer, TransformListener
from tf2_geometry_msgs import do_transform_point


class ObjectLocalizer(Node):

    def __init__(self):
        super().__init__('object_localizer')

        # 参数：话题名可通过 launch 改
        self.declare_parameter('rgb_topic', '/camera/image_raw')
        self.declare_parameter('depth_topic', '/camera/depth/image_raw')
        self.declare_parameter('camera_info_topic', '/camera/depth/camera_info')

        rgb_topic = self.get_parameter('rgb_topic').value
        depth_topic = self.get_parameter('depth_topic').value
        cam_info_topic = self.get_parameter('camera_info_topic').value

        # TF
        self.tf_buffer = Buffer()
        self.tf_listener = TransformListener(self.tf_buffer, self)

        # Bridge
        self.bridge = CvBridge()

        # 缓存
        self.rgb_img = None
        self.depth_img = None
        self.camera_info = None

        # 订阅：RGB / Depth / CameraInfo
        self.create_subscription(Image, rgb_topic, self.rgb_callback, 10)
        self.create_subscription(Image, depth_topic, self.depth_callback, 10)
        self.create_subscription(CameraInfo, cam_info_topic, self.camera_info_callback, 10)

        # 发布：颜色 & 物体位置
        self.color_pub = self.create_publisher(String, 'detected_color', 10)
        self.position_pub = self.create_publisher(PointStamped, 'object_position', 10)

        # 定时器：5Hz 检测
        self.timer = self.create_timer(0.2, self.timer_callback)

        self.get_logger().info(
            f"ObjectLocalizer started.\n"
            f"  RGB:   {rgb_topic}\n"
            f"  Depth: {depth_topic}\n"
            f"  Info:  {cam_info_topic}"
        )

    # ----------------- 回调：缓存图像和相机信息 ----------------- #

    def rgb_callback(self, msg: Image):
        self.rgb_img = self.bridge.imgmsg_to_cv2(msg, desired_encoding='bgr8')

    def depth_callback(self, msg: Image):
        self.depth_img = self.bridge.imgmsg_to_cv2(msg, desired_encoding='passthrough')

    def camera_info_callback(self, msg: CameraInfo):
        self.camera_info = msg

    # ----------------- 主检测逻辑（定时器） ----------------- #

    def timer_callback(self):
        if self.rgb_img is None or self.depth_img is None or self.camera_info is None:
            return

        img = self.rgb_img
        depth = self.depth_img
        cam_info = self.camera_info

        # 1. 颜色检测（HSV）
        hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)

        # 绿色阈值
        lower_green = np.array([35, 40, 40])
        upper_green = np.array([85, 255, 255])
        mask_green = cv2.inRange(hsv, lower_green, upper_green)

        # 红色阈值（双区间）
        lower_red1 = np.array([0, 100, 70])
        upper_red1 = np.array([10, 255, 255])
        lower_red2 = np.array([170, 100, 70])
        upper_red2 = np.array([180, 255, 255])
        mask_red = cv2.bitwise_or(
            cv2.inRange(hsv, lower_red1, upper_red1),
            cv2.inRange(hsv, lower_red2, upper_red2)
        )

        kernel = np.ones((5, 5), np.uint8)
        mask_green = cv2.morphologyEx(mask_green, cv2.MORPH_OPEN, kernel)
        mask_red = cv2.morphologyEx(mask_red, cv2.MORPH_OPEN, kernel)

        def largest_centroid(mask):
            contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
            if not contours:
                return None, 0.0
            cnt = max(contours, key=cv2.contourArea)
            area = cv2.contourArea(cnt)
            if area < 1500:   # 面积太小当噪声
                return None, area
            M = cv2.moments(cnt)
            if M["m00"] == 0:
                return None, area
            cx = int(M["m10"] / M["m00"])
            cy = int(M["m01"] / M["m00"])
            return (cx, cy), area

        green_center, green_area = largest_centroid(mask_green)
        red_center, red_area = largest_centroid(mask_red)

        color_msg = String()
        pixel = None

        if red_center is not None and red_area >= green_area:
            color_msg.data = "red"
            pixel = red_center
        elif green_center is not None:
            color_msg.data = "green"
            pixel = green_center
        else:
            # 什么都没检测到
            color_msg.data = "none"
            self.color_pub.publish(color_msg)
            return

        # 先发颜色给 main_controller
        self.color_pub.publish(color_msg)

        # 2. 从 depth 取该像素的深度
        cx, cy = pixel
        if cy < 0 or cy >= depth.shape[0] or cx < 0 or cx >= depth.shape[1]:
            return

        d = float(depth[cy][cx])
        if d <= 0.0 or math.isnan(d):
            return

        # 3. 使用 CameraInfo + pyrealsense2 反投影到相机坐标
        intr = rs.intrinsics()
        intr.width = cam_info.width
        intr.height = cam_info.height
        intr.ppx = cam_info.k[2]
        intr.ppy = cam_info.k[5]
        intr.fx = cam_info.k[0]
        intr.fy = cam_info.k[4]
        intr.model = rs.distortion.none
        intr.coeffs = list(cam_info.d)

        point_cam = rs.rs2_deproject_pixel_to_point(intr, [cx, cy], d)  # [X, Y, Z] in camera frame

        # 4. TF：从 camera_info.header.frame_id → map
        source_frame = cam_info.header.frame_id
        try:
            tf = self.tf_buffer.lookup_transform(
                'map',               # target
                source_frame,        # source
                Time()
            )
        except Exception as e:
            self.get_logger().warn(f"TF lookup failed: {e}")
            return

        point = PointStamped()
        point.header.frame_id = source_frame
        point.header.stamp = self.get_clock().now().to_msg()
        point.point.x = point_cam[0]
        point.point.y = point_cam[1]
        point.point.z = point_cam[2]

        point_world = do_transform_point(point, tf)
        point_world.header.frame_id = 'map'

        # 发布世界坐标
        self.position_pub.publish(point_world)

        self.get_logger().info(
            f"Detected {color_msg.data} at map: "
            f"({point_world.point.x:.2f}, {point_world.point.y:.2f})"
        )


def main(args=None):
    rclpy.init(args=args)
    node = ObjectLocalizer()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    node.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()
