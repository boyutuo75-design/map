#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import rclpy
from rclpy.node import Node
import random
import math
from geometry_msgs.msg import PoseStamped
from std_msgs.msg import Empty

class ExplorerNode(Node):
    def __init__(self) -> None:
        super().__init__('explorer_node')

        # 地图边界
        self.declare_parameter('min_x', -2.56)
        self.declare_parameter('max_x', 6.94)
        self.declare_parameter('min_y', -5.07)
        self.declare_parameter('max_y', 5.18)
        self.declare_parameter('map_frame', 'map')

        self.min_x = float(self.get_parameter('min_x').value)
        self.max_x = float(self.get_parameter('max_x').value)
        self.min_y = float(self.get_parameter('min_y').value)
        self.max_y = float(self.get_parameter('max_y').value)
        self.map_frame = self.get_parameter('map_frame').value

        # 1. 订阅：听 MainController 什么时候想要新目标
        self.request_sub = self.create_subscription(
            Empty,
            '/request_explore_goal',
            self.handle_goal_request,
            10
        )

        # 2. 发布：把生成好的坐标发回去
        self.goal_pub = self.create_publisher(PoseStamped, '/explore_goal_result', 10)

        self.get_logger().info('ExplorerNode (Topic Version) Initialised.')

    def handle_goal_request(self, msg):
        """收到请求，生成随机点并发布"""
        goal = self.create_random_goal()
        self.goal_pub.publish(goal)
        self.get_logger().info("Sent new random goal via topic.")

    def create_random_goal(self) -> PoseStamped:
        x = random.uniform(self.min_x, self.max_x)
        y = random.uniform(self.min_y, self.max_y)
        yaw = random.uniform(0, 2 * math.pi)

        qz = math.sin(yaw / 2.0)
        qw = math.cos(yaw / 2.0)

        goal = PoseStamped()
        goal.header.frame_id = self.map_frame
        goal.header.stamp = self.get_clock().now().to_msg()
        goal.pose.position.x = x
        goal.pose.position.y = y
        goal.pose.orientation.z = qz
        goal.pose.orientation.w = qw
        return goal

def main(args=None):
    rclpy.init(args=args)
    rclpy.spin(ExplorerNode())
    rclpy.shutdown()