#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Utils Module — 通用工具函数

功能：
- 从参数中加载颜色目标点（例如 red / green）
- 检查颜色是否有效
- 获取某颜色对应的坐标
"""

import rclpy


# ====================================================================== #
#                      加载颜色目标点（颜色 → [x, y]）                   #
# ====================================================================== #

def load_color_goals(node):
    """
    从参数服务器加载颜色目标点坐标。

    参数格式（由 launch 文件传入）：
        red_goal:   [x, y]
        green_goal: [x, y]

    返回：
        {
            "red":   [x, y],
            "green": [x, y]
        }
    """

    supported_colors = ["red", "green"]
    color_goals = {}

    for color in supported_colors:
        param_name = f"{color}_goal"

        # 若参数未声明，声明默认值（避免报错）
        if not node.has_parameter(param_name):
            node.declare_parameter(param_name, [0.0, 0.0])

        value = node.get_parameter(param_name).get_parameter_value().double_array_value

        # 参数至少包含 x,y
        if len(value) >= 2:
            color_goals[color] = [value[0], value[1]]
        else:
            node.get_logger().warn(
                f"Parameter {param_name} is invalid — must contain at least [x, y]."
            )

    # 打印加载结果（调试用途）
    node.get_logger().info(f"Loaded color goals: {color_goals}")

    return color_goals


# ====================================================================== #
#                          颜色是否有效                                   #
# ====================================================================== #

def is_valid_color(color, goals_dict):
    """
    检查识别的颜色是否在预定义目标点中存在。

    返回：
        True  —— 有效（可使用）
        False —— 无效（目标点未定义）
    """
    return color in goals_dict


# ====================================================================== #
#                     获取某个颜色的导航目标点                            #
# ====================================================================== #

def get_color_goal(color, goals_dict):
    """
    给出颜色（red / green），返回其坐标 [x, y]

    若颜色无效，则返回 None
    """

    if color not in goals_dict:
        return None

    return goals_dict[color]


# ====================================================================== #
#                      打印工具（可选，用于 debug）                       #
# ====================================================================== #

def print_color_goals(node, goals_dict):
    """打印所有颜色目标点（可用于系统启动调试）"""
    for color, xy in goals_dict.items():
        node.get_logger().info(f"Goal for {color}: x={xy[0]}, y={xy[1]}")
