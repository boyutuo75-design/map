#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from launch import LaunchDescription
from launch_ros.actions import Node


def generate_launch_description():

    map_bounds = {
        'min_x': -2.56,
        'max_x':  6.94,
        'min_y': -5.07,
        'max_y':  5.18,
        'map_frame': 'map'
    }

    explorer_node = Node(
        package='coursework',
        executable='explorer_node',
        name='explorer_node',
        parameters=[map_bounds]
    )

    main_controller_node = Node(
        package='coursework',
        executable='main_controller',
        name='main_controller',
        parameters=[{'max_run_time': 300.0}]
    )

    navigator_node = Node(
        package='coursework',
        executable='navigator',
        name='navigator'
    )

    marker_publisher_node = Node(
        package='coursework',
        executable='marker_publisher',
        name='marker_publisher',
        parameters=[{'map_frame': 'map'}]
    )

    object_localizer_node = Node(
        package='coursework',
        executable='object_localizer',
        name='object_localizer',
        parameters=[
            {'rgb_topic':   '/camera/image_raw'},
            {'depth_topic': '/camera/depth/image_raw'},
            {'camera_info_topic': '/camera/depth/camera_info'}
        ]
    )

    return LaunchDescription([
        explorer_node,
        main_controller_node,
        navigator_node,
        marker_publisher_node,
        object_localizer_node
    ])
