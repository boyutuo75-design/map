from setuptools import setup
from glob import glob
import os

package_name = 'coursework'

setup(
    name=package_name,
    version='0.0.1',
    packages=[package_name],
    data_files=[
        ('share/ament_index/resource_index/packages',
         ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
        ('share/' + package_name + '/launch', glob('launch/*.launch.py')),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='student',
    maintainer_email='student@example.com',
    description='Robot search coursework',
    license='Apache License 2.0',
    tests_require=['pytest'],
    entry_points={
        'console_scripts': [
            'explorer_node = coursework.explorer_node:main',
            'main_controller = coursework.main_controller:main',
            'navigator = coursework.navigator:main',
            'marker_publisher = coursework.marker_publisher:main',
            'object_localizer = coursework.object_localizer:main',
        ],
    },
)