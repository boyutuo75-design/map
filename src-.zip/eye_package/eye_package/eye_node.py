import rclpy
import math
from rclpy.node import Node
from geometry_msgs.msg import Quaternion, PointStamped
from sensor_msgs.msg import Image, CameraInfo
from nav_msgs.msg import Odometry
from cv_bridge import CvBridge
from tf2_ros import TransformListener, Buffer
from tf2_geometry_msgs import do_transform_point
import numpy as np
import cv2
import pyrealsense2 as rs

def quaternion_to_rpy(q: Quaternion):
    """
    Convert a quaternion into roll, pitch, and yaw (in radians).
    """
    x, y, z, w = q.x, q.y, q.z, q.w

    # Roll (x-axis rotation)
    sinr_cosp = 2 * (w * x + y * z)
    cosr_cosp = 1 - 2 * (x * x + y * y)
    roll = math.atan2(sinr_cosp, cosr_cosp)

    # Pitch (y-axis rotation)
    sinp = 2 * (w * y - z * x)
    if abs(sinp) >= 1:
        pitch = math.copysign(math.pi / 2, sinp)  # use 90 degrees if out of range
    else:
        pitch = math.asin(sinp)

    # Yaw (z-axis rotation)
    siny_cosp = 2 * (w * z + x * y)
    cosy_cosp = 1 - 2 * (y * y + z * z)
    yaw = math.atan2(siny_cosp, cosy_cosp)

    return roll, pitch, yaw

class ImageSubscriber(Node):
    
    def __init__(self):
        super().__init__('image_subscriber')
        self.tf_buffer = Buffer()
        self.tf_listener = TransformListener(self.tf_buffer, self)
        
        self.subscription_image = self.create_subscription(
            Image,
            '/camera_depth/image_raw',
            self.image_callback,
            10)
        
        self.subscription_dimage = self.create_subscription(
            Image,
            '/camera_depth/depth/image_raw',
            self.dimage_callback,
            10)
        
        self.subscription_int = self.create_subscription(
            CameraInfo,
            '/camera_depth/camera_info',
            self.ins_callback,
            10)

        self.subscription = self.create_subscription(
            Odometry,
            'odom',
            self.odom_callback,
            10)
        
        self.ins = None
        self.image = []
        self.dimage = []
        
        self.br = CvBridge()
        
        self.timer = self.create_timer(0.2, self.timer_callback)
    
    def odom_callback(self, msg):
        self.location = (msg.pose.pose.position.x, msg.pose.pose.position.y, msg.pose.pose.position.z)
        _, _, self.orientation = quaternion_to_rpy(msg.pose.pose.orientation)
    
    def ins_callback(self, data):
        self.ins = data
    
    def tf_from_cam_to_map(self):
        from_frame = 'camera_rgb_optical_frame'
        to_frame = 'map'
        
        now = rclpy.time.Time()
        
        try:
            tf = self.tf_buffer.lookup_transform(to_frame, from_frame, now, timeout=rclpy.duration.Duration(seconds=1.0))
            return tf
        except:
            return None
        
    def image_callback(self, data):
        #self.get_logger().info('Receiving video frame')
    
        current_frame = self.br.imgmsg_to_cv2(data, desired_encoding='bgr8')
        
        self.image = current_frame
        
    def dimage_callback(self, data):
        #self.get_logger().info('Receiving dvideo frame')
    
        current_frame = self.br.imgmsg_to_cv2(data, desired_encoding='passthrough')
        
        self.dimage = current_frame
        
    def timer_callback(self):
        # 当前彩色图像
        current_frame = self.image
        if current_frame == []:
            return

        # 当前深度图像
        depth_frame = self.dimage
        if depth_frame == []:
            return

        # 这两个列表是老师给的接口：后面 rs2_deproject_pixel_to_point 会用到
        centroids = []  # RGB 图像上的像素坐标 (x, y)
        depths = []     # 对应像素处的深度值

        # 转 HSV
        hsv = cv2.cvtColor(current_frame, cv2.COLOR_BGR2HSV)

        # ---------- 1. 生成红色和绿色的掩膜（HSV 空间） ----------
        # 红色（消防栓）：分成两段 Hue
        lower_red1 = np.array([0, 70, 50])
        upper_red1 = np.array([10, 255, 255])
        lower_red2 = np.array([170, 70, 50])
        upper_red2 = np.array([180, 255, 255])
        mask_red = cv2.inRange(hsv, lower_red1, upper_red1) + \
                   cv2.inRange(hsv, lower_red2, upper_red2)

        # 绿色（垃圾桶：颜色较深，所以 S/V 放宽一点）
        lower_green = np.array([35, 30, 30])
        upper_green = np.array([90, 255, 255])
        mask_green = cv2.inRange(hsv, lower_green, upper_green)

        # 去噪：开运算
        kernel = np.ones((5, 5), np.uint8)
        mask_red = cv2.morphologyEx(mask_red, cv2.MORPH_OPEN, kernel)
        mask_green = cv2.morphologyEx(mask_green, cv2.MORPH_OPEN, kernel)

        h_d, w_d = depth_frame.shape[:2]

        # ---------- 2. 处理红色目标：选出“像消防栓”的最大轮廓 ----------
        contours_red, _ = cv2.findContours(
            mask_red, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE
        )

        candidate_red = None
        best_area_red = 0.0

        for cnt in contours_red:
            area = cv2.contourArea(cnt)
            if area < 800:             # 太小的当噪声
                continue
            x, y, w, h = cv2.boundingRect(cnt)
            if w == 0:
                continue
            aspect = h / float(w)      # 高宽比，消防栓偏“竖直”
            if aspect < 1.1:           # 太扁的（像砖块）不要
                continue
            if area > best_area_red:
                best_area_red = area
                candidate_red = (x, y, w, h)

        if candidate_red is not None:
            x, y, w, h = candidate_red
            cx = int(x + w / 2)
            cy = int(y + h / 2)

            # 用大红框框住整个目标 + 中心点 + 文本 “red”
            cv2.rectangle(current_frame, (x, y), (x + w, y + h),
                          (0, 0, 255), 2)
            cv2.circle(current_frame, (cx, cy), 5, (0, 0, 255), -1)
            cv2.putText(current_frame, "red", (x, y - 5),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 0, 255), 1)

            if 0 <= cx < w_d and 0 <= cy < h_d:
                d = float(depth_frame[cy, cx])
                if d > 0 and not math.isinf(d) and not math.isnan(d):
                    centroids.append([cx, cy])
                    depths.append(d)

        # ---------- 3. 处理绿色目标：垃圾桶，取最大轮廓 ----------
        contours_green, _ = cv2.findContours(
            mask_green, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE
        )

        candidate_green = None
        best_area_green = 0.0

        for cnt in contours_green:
            area = cv2.contourArea(cnt)
            if area < 1500:            # 垃圾桶比较大，小的不要
                continue
            x, y, w, h = cv2.boundingRect(cnt)
            if area > best_area_green:
                best_area_green = area
                candidate_green = (x, y, w, h)

        if candidate_green is not None:
            x, y, w, h = candidate_green
            cx = int(x + w / 2)
            cy = int(y + h / 2)

            # 绿色大框 + 中心点 + 文本 “green”
            cv2.rectangle(current_frame, (x, y), (x + w, y + h),
                          (0, 255, 0), 2)
            cv2.circle(current_frame, (cx, cy), 5, (0, 255, 0), -1)
            cv2.putText(current_frame, "green", (x, y - 5),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 1)

            if 0 <= cx < w_d and 0 <= cy < h_d:
                d = float(depth_frame[cy, cx])
                if d > 0 and not math.isinf(d) and not math.isnan(d):
                    centroids.append([cx, cy])
                    depths.append(d)

        # 如果一个目标都没找到，就只显示画面，不再往下做 3D 投影
        if len(centroids) == 0:
            cv2.imshow("camera", current_frame)
            cv2.waitKey(1)
            return

        # 下面这一部分保持你原来的逻辑，不要改
        if self.ins is None:
            return

        cameraInfo = self.ins

        _intrinsics = rs.intrinsics()
        _intrinsics.width = cameraInfo.width
        _intrinsics.height = cameraInfo.height
        _intrinsics.ppx = cameraInfo.k[2]
        _intrinsics.ppy = cameraInfo.k[5]
        _intrinsics.fx = cameraInfo.k[0]
        _intrinsics.fy = cameraInfo.k[4]
        _intrinsics.model = rs.distortion.none
        _intrinsics.coeffs = [i for i in cameraInfo.d]

        points_3d = [rs.rs2_deproject_pixel_to_point(
            _intrinsics, centroids[x], depths[x]
        ) for x in range(len(centroids))]

        point = PointStamped()
        point.header.frame_id = 'map'
        point.point.x = points_3d[0][0]
        point.point.y = points_3d[0][1]
        point.point.z = points_3d[0][2]

        tf = self.tf_from_cam_to_map()
        if tf == None:
            return  # Exit function if tf failed.
        point_world = do_transform_point(point, tf)

        print(point_world.point.x, point_world.point.y)

        cv2.imshow("camera", current_frame)
        cv2.waitKey(1)

        
        
        if self.ins is None:
            return

        cameraInfo = self.ins

        _intrinsics = rs.intrinsics()
        _intrinsics.width = cameraInfo.width
        _intrinsics.height = cameraInfo.height
        _intrinsics.ppx = cameraInfo.k[2]
        _intrinsics.ppy = cameraInfo.k[5]
        _intrinsics.fx = cameraInfo.k[0]
        _intrinsics.fy = cameraInfo.k[4]
        _intrinsics.model = rs.distortion.none
        _intrinsics.coeffs = [i for i in cameraInfo.d]

        points_3d = [rs.rs2_deproject_pixel_to_point(_intrinsics, centroids[x], depths[x]) for x in range(len(centroids))]
        
        point = PointStamped()
        point.header.frame_id = 'map'
        point.point.x = points_3d[0][0]
        point.point.y = points_3d[0][1]
        point.point.z = points_3d[0][2]

        tf = self.tf_from_cam_to_map()
        if tf == None: return #Exit function if tf failed.
        point_world = do_transform_point(point, tf)
        
        print(point_world.point.x, point_world.point.y)
        
        cv2.imshow("camera", current_frame)
        cv2.waitKey(1)

def main(args=None):
    rclpy.init(args=args)
    image_subscriber = ImageSubscriber()
    rclpy.spin(image_subscriber)
    image_subscriber.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
