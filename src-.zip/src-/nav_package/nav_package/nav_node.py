#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import math
import rclpy
from rclpy.node import Node

from geometry_msgs.msg import PoseStamped
from rclpy.action import ActionClient
from nav2_msgs.action import NavigateToPose
from rclpy.action.client import GoalStatus


class Nav2WaypointFollower(Node):
    def __init__(self):
        super().__init__("nav2_waypoint_follower")

        # Nav2 action 客户端
        self.nav_action = ActionClient(self, NavigateToPose, "navigate_to_pose")

        # 你的路径点（map 坐标）
        self.waypoints = [
            (-0.196, 0.985),
            (-0.27,  2.96),
            (-0.18,  3.89),
            (-0.232, 4.24),
            (0.691, 4.26),
            (1.02,  4.22),
            (1.09,  3.51),
            (1.08,  2.83),
            (1.08,  2.32),
            (2.02,  2.07),
            (3.04,  2.11),
            (3.78,  2.88),
            (3.84,  3.51),
            (4.18,  4.15),
            (3.22,  4.16),
            (2.23,  4.15),
            (1.24,  4.14),
            (0.589, 4.27),
            (0.156, 4.28),
            (-0.202, 4.13),
            (-0.314, 3.46),
            (-0.26,  2.76),
            (-0.257, 1.16),
        ]

        self.index = 0
        self.is_navigating = False
        self.current_goal_handle = None

        # 1 Hz：检查是否需要发下一个点
        self.timer = self.create_timer(1.0, self.loop)
        self.get_logger().info("Nav2 Waypoint Follower 启动，等待 Nav2...")

    # ========= 核心循环 =========
    def loop(self):
        # Nav2 还没起来
        if not self.nav_action.server_is_ready():
            self.get_logger().info("等待 Nav2 启动中……")
            return

        # 还在导航，不发新目标
        if self.is_navigating:
            return

        # 路径点走完
        if self.index >= len(self.waypoints):
            self.get_logger().info("✅ 已完成全部路径点")
            self.timer.cancel()
            return

        # 发送当前 waypoint
        x, y = self.waypoints[self.index]

        # === 关键改动 1：计算朝向，让机器人面向“下一个点” ===
        yaw = 0.0
        if self.index < len(self.waypoints) - 1:
            next_x, next_y = self.waypoints[self.index + 1]
            dx = next_x - x
            dy = next_y - y
            # 如果下一个点不在同一位置，才计算方向
            if abs(dx) > 1e-3 or abs(dy) > 1e-3:
                yaw = math.atan2(dy, dx)   # 机器人朝向下一个点
        # roll = pitch = 0，只需要 yaw，对应四元数：
        qz = math.sin(yaw / 2.0)
        qw = math.cos(yaw / 2.0)

        self.get_logger().info(
            f"👉 发送第 {self.index+1}/{len(self.waypoints)} 个目标: "
            f"({x:.2f}, {y:.2f}), yaw={math.degrees(yaw):.1f}°"
        )

        pose = PoseStamped()
        pose.header.frame_id = "map"
        pose.header.stamp = self.get_clock().now().to_msg()
        pose.pose.position.x = x
        pose.pose.position.y = y
        pose.pose.position.z = 0.0
        pose.pose.orientation.x = 0.0
        pose.pose.orientation.y = 0.0
        pose.pose.orientation.z = qz
        pose.pose.orientation.w = qw

        goal_msg = NavigateToPose.Goal()
        goal_msg.pose = pose

        self.send_goal(goal_msg)

    # ========= 发送 goal =========
    def send_goal(self, goal):
        future = self.nav_action.send_goal_async(goal)
        future.add_done_callback(self.goal_response_callback)
        self.is_navigating = True

    # ========= Nav2 接受 / 拒绝 =========
    def goal_response_callback(self, future):
        goal_handle = future.result()
        if not goal_handle.accepted:
            self.get_logger().warn("❌ Nav2 拒绝当前目标，跳到下一个点")
            self.is_navigating = False
            self.index += 1
            return

        self.get_logger().info("✔ Nav2 已接受目标，开始导航")
        self.current_goal_handle = goal_handle
        result_future = goal_handle.get_result_async()
        result_future.add_done_callback(self.result_callback)

    # ========= 到 / 没到 目标 =========
    def result_callback(self, future):
        result = future.result()
        status = result.status

        # 导航结束，允许下一个 loop 发送新目标
        self.is_navigating = False

        if status == GoalStatus.STATUS_SUCCEEDED:
            self.get_logger().info("🎯 到达当前目标点（Nav2 判定成功）")
        else:
            self.get_logger().warn(f"⚠ 当前目标未成功（status={status}），继续前往下一个点")

        # === 关键改动 2：不再人为 sleep 1 秒，马上进入下一个点 ===
        self.index += 1


def main(args=None):
    rclpy.init(args=args)
    node = Nav2WaypointFollower()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()


if __name__ == "__main__":
    main()

