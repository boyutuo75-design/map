^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package turtlebot3_manipulation_gazebo
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

2.3.8 (2025-07-10)
------------------
* Fixed the issue where the TurtleBot3 Manipulation Gazebo simulation was not working properly
* Contributors: Hyungyu Kim

2.3.6 (2025-06-19)
------------------
* None

2.3.4 (2025-05-28)
------------------
* Moved the TurtleBot3 Manipulation Gazebo simulation from the turtlebot3_manipulation_bringup package
* Contributors: ChanHyeong Lee
