import rclpy
import math
from rclpy.node import Node
from geometry_msgs.msg import Quaternion, PointStamped, Point
from visualization_msgs.msg import Marker

from sensor_msgs.msg import Image, CameraInfo
from nav_msgs.msg import Odometry
from cv_bridge import CvBridge
from tf2_ros import TransformListener, Buffer
from tf2_geometry_msgs import do_transform_point
import numpy as np
import cv2
import pyrealsense2 as rs


def quaternion_to_rpy(q: Quaternion):
    """
    Convert a quaternion into roll, pitch, and yaw (in radians).
    """
    x, y, z, w = q.x, q.y, q.z, q.w

    # Roll (x-axis rotation)
    sinr_cosp = 2 * (w * x + y * z)
    cosr_cosp = 1 - 2 * (x * x + y * y)
    roll = math.atan2(sinr_cosp, cosr_cosp)

    # Pitch (y-axis rotation)
    sinp = 2 * (w * y - z * x)
    if abs(sinp) >= 1:
        pitch = math.copysign(math.pi / 2, sinp)  # use 90 degrees if out of range
    else:
        pitch = math.asin(sinp)

    # Yaw (z-axis rotation)
    siny_cosp = 2 * (w * z + x * y)
    cosy_cosp = 1 - 2 * (y * y + z * z)
    yaw = math.atan2(siny_cosp, cosy_cosp)

    return roll, pitch, yaw


class ImageSubscriber(Node):

    def __init__(self):
        super().__init__('image_subscriber')
        self.tf_buffer = Buffer()
        self.tf_listener = TransformListener(self.tf_buffer, self)

        self.subscription_image = self.create_subscription(
            Image,
            '/camera_depth/image_raw',
            self.image_callback,
            10)

        self.subscription_dimage = self.create_subscription(
            Image,
            '/camera_depth/depth/image_raw',
            self.dimage_callback,
            10)

        self.subscription_int = self.create_subscription(
            CameraInfo,
            '/camera_depth/camera_info',
            self.ins_callback,
            10)

        self.subscription = self.create_subscription(
            Odometry,
            'odom',
            self.odom_callback,
            10)

        self.ins = None
        self.image = []
        self.dimage = []

        self.br = CvBridge()

        self.timer = self.create_timer(0.2, self.timer_callback)

        # ----------- Marker 相关：在地图上标红点、绿点 -----------
        self.red_marker_pub = self.create_publisher(Marker, 'red_object_marker', 10)
        self.green_marker_pub = self.create_publisher(Marker, 'green_object_marker', 10)

        self.red_markers = []
        self.green_markers = []
        self.red_next_id = 0
        self.green_next_id = 0

        # 认为是“同一个物体”的距离阈值（米）
        self.marker_dist_threshold = 0.4
        # 最多标 5 个红球 + 5 个绿球（可按需要改）
        self.max_red_markers = 5
        self.max_green_markers = 5
        # --------------------------------------------------------

    def odom_callback(self, msg):
        self.location = (msg.pose.pose.position.x,
                         msg.pose.pose.position.y,
                         msg.pose.pose.position.z)
        _, _, self.orientation = quaternion_to_rpy(msg.pose.pose.orientation)

    def ins_callback(self, data):
        self.ins = data

    def tf_from_cam_to_map(self):
        from_frame = 'camera_rgb_optical_frame'
        to_frame = 'map'

        now = rclpy.time.Time()

        try:
            tf = self.tf_buffer.lookup_transform(
                to_frame, from_frame, now,
                timeout=rclpy.duration.Duration(seconds=1.0))
            return tf
        except Exception:
            return None

    def image_callback(self, data):
        current_frame = self.br.imgmsg_to_cv2(
            data, desired_encoding='bgr8')
        self.image = current_frame

    def dimage_callback(self, data):
        current_frame = self.br.imgmsg_to_cv2(
            data, desired_encoding='passthrough')
        self.dimage = current_frame

    # ---------- 静态 marker：只第一次看到时记录，后续不再移动 ----------
    def add_static_marker(self, color: str, x: float, y: float, z: float):
        if color == 'red':
            markers_list = self.red_markers
            max_markers = self.max_red_markers
            ns = 'red_objects'
            pub = self.red_marker_pub
            next_id_name = 'red_next_id'
        else:
            markers_list = self.green_markers
            max_markers = self.max_green_markers
            ns = 'green_objects'
            pub = self.green_marker_pub
            next_id_name = 'green_next_id'

        # 1. 如果附近已经有 marker，认为是同一个物体，不新增
        for m in markers_list:
            dx = x - m.pose.position.x
            dy = y - m.pose.position.y
            dz = z - m.pose.position.z
            dist = math.sqrt(dx * dx + dy * dy + dz * dz)
            if dist < self.marker_dist_threshold:
                return

        # 2. 已达到上限，不再新增
        if len(markers_list) >= max_markers:
            return

        # 3. 新建一个 marker（静态）
        m = Marker()
        m.header.frame_id = 'map'
        m.header.stamp = self.get_clock().now().to_msg()
        m.ns = ns
        m.id = getattr(self, next_id_name)
        setattr(self, next_id_name, getattr(self, next_id_name) + 1)

        m.type = Marker.SPHERE
        m.action = Marker.ADD

        m.pose.position.x = x
        m.pose.position.y = y
        m.pose.position.z = z
        m.pose.orientation.x = 0.0
        m.pose.orientation.y = 0.0
        m.pose.orientation.z = 0.0
        m.pose.orientation.w = 1.0

        m.scale.x = 0.2
        m.scale.y = 0.2
        m.scale.z = 0.2

        if color == 'red':
            m.color.r = 1.0
            m.color.g = 0.0
            m.color.b = 0.0
        else:
            m.color.r = 0.0
            m.color.g = 1.0
            m.color.b = 0.0
        m.color.a = 1.0

        markers_list.append(m)
        pub.publish(m)

    # ----------------------------------------------------------------

    def timer_callback(self):
        # 当前彩色图像
        current_frame = self.image
        if current_frame == []:
            return

        # 当前深度图像
        depth_frame = self.dimage
        if depth_frame == []:
            return

        # 转 HSV
        hsv = cv2.cvtColor(current_frame, cv2.COLOR_BGR2HSV)

        centroids = []  # 像素坐标
        depths = []     # 深度值

        # 用于 marker 的像素+深度记录
        red_pixel = None
        red_depth = None
        green_pixel = None
        green_depth = None

        # ---------- C. 生成红色和绿色的掩膜（HSV 空间） ----------
        # 红色（消防栓）：分成两段 Hue（阈值可按需要再调整）
        lower_red1 = np.array([0, 70, 50])
        upper_red1 = np.array([10, 255, 255])
        lower_red2 = np.array([170, 70, 50])
        upper_red2 = np.array([180, 255, 255])
        mask_red = cv2.inRange(hsv, lower_red1, upper_red1) + \
                   cv2.inRange(hsv, lower_red2, upper_red2)

        # 绿色（垃圾桶：你目前调好的阈值）
        lower_green = np.array([45, 100, 0])
        upper_green = np.array([60, 255, 180])
        mask_green = cv2.inRange(hsv, lower_green, upper_green)

        # 去噪：开运算
        kernel = np.ones((5, 5), np.uint8)
        mask_red = cv2.morphologyEx(mask_red, cv2.MORPH_OPEN, kernel)
        mask_green = cv2.morphologyEx(mask_green, cv2.MORPH_OPEN, kernel)

        # 合并红 + 绿 掩膜，用来显示“红绿色检测窗口”
        mask_rg = cv2.bitwise_or(mask_red, mask_green)

        h_d, w_d = depth_frame.shape[:2]

        # ---------- D. 红色目标 ----------
        contours_red, _ = cv2.findContours(
            mask_red, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE
        )

        candidate_red = None
        best_area_red = 0.0

        for cnt in contours_red:
            area = cv2.contourArea(cnt)
            if area < 800:
                continue
            x, y, w, h = cv2.boundingRect(cnt)
            if w == 0:
                continue
            aspect = h / float(w)
            if aspect < 1.1:
                continue
            if area > best_area_red:
                best_area_red = area
                candidate_red = (x, y, w, h)

        if candidate_red is not None:
            x, y, w, h = candidate_red
            cx = int(x + w / 2)
            cy = int(y + h / 2)

            cv2.rectangle(current_frame, (x, y), (x + w, y + h),
                          (0, 0, 255), 2)
            cv2.circle(current_frame, (cx, cy), 5, (0, 0, 255), -1)
            cv2.putText(current_frame, "red", (x, y - 5),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 0, 255), 1)

            if 0 <= cx < w_d and 0 <= cy < h_d:
                d = float(depth_frame[cy, cx])
                if d > 0 and not math.isinf(d) and not math.isnan(d):
                    centroids.append([cx, cy])
                    depths.append(d)
                    red_pixel = (cx, cy)
                    red_depth = d

        # ---------- E. 绿色目标 ----------
        contours_green, _ = cv2.findContours(
            mask_green, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE
        )

        candidate_green = None
        best_area_green = 0.0

        for cnt in contours_green:
            area = cv2.contourArea(cnt)
            if area < 1500:
                continue
            x, y, w, h = cv2.boundingRect(cnt)
            if area > best_area_green:
                best_area_green = area
                candidate_green = (x, y, w, h)

        if candidate_green is not None:
            x, y, w, h = candidate_green
            cx = int(x + w / 2)
            cy = int(y + h / 2)

            cv2.rectangle(current_frame, (x, y), (x + w, y + h),
                          (0, 255, 0), 2)
            cv2.circle(current_frame, (cx, cy), 5, (0, 255, 0), -1)
            cv2.putText(current_frame, "green", (x, y - 5),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 1)

            if 0 <= cx < w_d and 0 <= cy < h_d:
                d = float(depth_frame[cy, cx])
                if d > 0 and not math.isinf(d) and not math.isnan(d):
                    centroids.append([cx, cy])
                    depths.append(d)
                    green_pixel = (cx, cy)
                    green_depth = d

        # 没有目标：只显示两个窗口
        if len(centroids) == 0:
            cv2.imshow("camera", current_frame)
            cv2.imshow("camera_red_green_mask", mask_rg)
            cv2.waitKey(1)
            return

        # ---------- F. 老师的 3D 投影逻辑（保持不动） ----------
        if self.ins is None:
            return

        cameraInfo = self.ins

        _intrinsics = rs.intrinsics()
        _intrinsics.width = cameraInfo.width
        _intrinsics.height = cameraInfo.height
        _intrinsics.ppx = cameraInfo.k[2]
        _intrinsics.ppy = cameraInfo.k[5]
        _intrinsics.fx = cameraInfo.k[0]
        _intrinsics.fy = cameraInfo.k[4]
        _intrinsics.model = rs.distortion.none
        _intrinsics.coeffs = [i for i in cameraInfo.d]

        points_3d = [rs.rs2_deproject_pixel_to_point(
            _intrinsics, centroids[x], depths[x]
        ) for x in range(len(centroids))]

        point = PointStamped()
        point.header.frame_id = 'map'
        point.point.x = points_3d[0][0]
        point.point.y = points_3d[0][1]
        point.point.z = points_3d[0][2]

        tf = self.tf_from_cam_to_map()
        if tf is None:
            return

        point_world = do_transform_point(point, tf)
        print(point_world.point.x, point_world.point.y)

        # ---------- G. 在 map 上添加静态 Marker ----------
        try:
            if red_pixel is not None and red_depth is not None:
                red_cam = rs.rs2_deproject_pixel_to_point(
                    _intrinsics, list(red_pixel), red_depth)
                red_ps = PointStamped()
                red_ps.header.frame_id = 'camera_rgb_optical_frame'
                red_ps.header.stamp = self.get_clock().now().to_msg()
                red_ps.point.x = red_cam[0]
                red_ps.point.y = red_cam[1]
                red_ps.point.z = red_cam[2]
                red_world = do_transform_point(red_ps, tf)

                self.add_static_marker(
                    'red',
                    red_world.point.x,
                    red_world.point.y,
                    0.2
                )

            if green_pixel is not None and green_depth is not None:
                green_cam = rs.rs2_deproject_pixel_to_point(
                    _intrinsics, list(green_pixel), green_depth)
                green_ps = PointStamped()
                green_ps.header.frame_id = 'camera_rgb_optical_frame'
                green_ps.header.stamp = self.get_clock().now().to_msg()
                green_ps.point.x = green_cam[0]
                green_ps.point.y = green_cam[1]
                green_ps.point.z = green_cam[2]
                green_world = do_transform_point(green_ps, tf)

                self.add_static_marker(
                    'green',
                    green_world.point.x,
                    green_world.point.y,
                    0.2
                )
        except Exception as e:
            self.get_logger().warn(f'添加静态 marker 失败: {e}')

        # 重发所有已记录的 marker，保证 RViz 一直显示
        for m in self.red_markers:
            m.header.stamp = self.get_clock().now().to_msg()
            self.red_marker_pub.publish(m)

        for m in self.green_markers:
            m.header.stamp = self.get_clock().now().to_msg()
            self.green_marker_pub.publish(m)

        # ---------- H. 显示两个窗口 ----------
        cv2.imshow("camera", current_frame)
        cv2.imshow("camera_red_green_mask", mask_rg)
        cv2.waitKey(1)


def main(args=None):
    rclpy.init(args=args)
    image_subscriber = ImageSubscriber()
    rclpy.spin(image_subscriber)
    image_subscriber.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()

