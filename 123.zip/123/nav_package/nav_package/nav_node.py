#!/usr/bin/env python3

import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist
from sensor_msgs.msg import LaserScan
import math
import numpy as np
import time

# TF 坐标变换库
from tf2_ros import Buffer, TransformListener

class ManualPatrolBot(Node):
    def __init__(self):
        super().__init__('manual_patrol_bot')

        # === 1. 参数配置 ===
        self.TARGET_TOLERANCE = 0.25   # 到达判定距离
        self.OBSTACLE_DIST = 0.50      # 触发避障模式的距离 (前方)
        self.CRITICAL_DIST = 0.15      # 全向紧急避让距离
        self.WALL_DIST = 0.50          # 沿墙走时保持的距离
        
        self.CHECK_INTERVAL = 2.0      # 直连路径检测间隔
        self.GIVE_UP_TIME = 40.0       # 避障超时时间
        
        # 旋转参数
        self.SPIN_SPEED_Z = 0.8        # 旋转角速度 (rad/s)
        self.SPIN_DURATION_360 = 8.0   # 360度旋转耗时 (约6.4弧度)
        self.SPIN_DURATION_180 = 4.0   # 180度旋转耗时 (约3.2弧度)
        
        # 速度设置
        self.MAX_SPEED = 0.25
        self.TURN_SPEED = 0.6
        
        # 坐标列表 
        # 格式: (x, y) 或 (x, y, 'ACTION_TAG')
        self.route_points = [
            # --- 第一批 ---
           (-0.20, 0.98), (-0.27, 2.96), (-0.18, 3.89), (-0.23, 4.24),(0.69, 4.26),  (1.02, 4.22),  (1.09, 3.51),  (1.08, 2.83),(1.08, 2.32),  (2.02, 2.07),  (3.04, 2.11),  (3.78, 2.88),(3.84, 3.51),  (4.18, 4.15),  (3.22, 4.16),  (2.23, 4.15),(1.24, 4.14),  (0.589, 4.27), (0.156, 4.28), (-0.202, 4.13),(-0.314, 3.46), (-0.26, 2.76), (-0.257, 1.16),
            
            # --- 第二批 ---
            (-0.337, -0.383), (-0.801, -0.749), (-1.4, -0.809), (-1.45, -0.115),(-1.74, 0.3),(-1.75, 0),
            (-1.61, 0.129),(-1.67, 0.213),(-1.75, 0.224),(-1.82, 0.132),(-1.82, 0.00489),(-1.73,-0.475),
            (-1.5, -1.0), (-1.5, -1.0), (-1.0, -1.0), (0.0, -1.0),
            

            # --- 第三批 ---
            (0.0, -1.0), (0.0, -2.0), (0.0, -3.8), (3.0, -3.8),
            (2.0, -2.0), (3.0, -1.0), (3.0, 0.0), (3.45, 0.88),

            # --- 第四批 ---
            (4.0, 1.0), (4.36, 0.756), (4.81, -0.0233), (5.0, -1.0),
            (4.75, -2.0), (4.56, -2.98), (4.83, -3.93), (5.72, -3.88),
            (6.0, -3.0), (6.0, -2.0), (6.0, -1.0), (6.0, 0.0),
            (6.0, 1.0), (6.0, 2.0), (6.0, 3.0), (6.0, 3.9),
            (5.0, 4.0), (5.0, 3.0), (5.0, 2.0), (5.0, 1.0)
        ]
        self.route_idx = 0

        # === 状态机定义 ===
        # 1. "NAV": 导航
        # 2. "WALL_FOLLOW": 沿墙
        # 3. "SPINNING": 原地旋转任务
        self.state = "NAV" 
        
        self.last_check_time = 0
        self.obstacle_start_time = 0
        
        # 旋转任务相关变量
        self.spin_start_time = 0
        self.target_spin_duration = 0.0  # 动态存储当前需要的旋转时间

        # === 硬件接口 ===
        self.pub_cmd = self.create_publisher(Twist, 'cmd_vel', 10)
        self.sub_scan = self.create_subscription(LaserScan, '/scan', self.lidar_cb, 10)

        # === 工具 ===
        self.tf_buff = Buffer()
        self.tf_listen = TransformListener(self.tf_buff, self)
        self.scan_data = None
        
        self.control_timer = self.create_timer(0.1, self.loop_step)
        self.get_logger().info("巡逻节点启动 (含180度掉头功能)...")

    def lidar_cb(self, msg): 
        self.scan_data = msg

    def loop_step(self):
        if self.route_idx >= len(self.route_points):
            self.stop_robot()
            self.get_logger().info("任务结束。")
            return

        rob_x, rob_y, rob_yaw = self.get_robot_pose()
        if rob_x is None: return 

        # 解析当前目标点
        current_pt = self.route_points[self.route_idx]
        target_x = current_pt[0]
        target_y = current_pt[1]
        
        # === 0. 解析特殊动作标签 ===
        # 只有当 tuple 长度大于 2 时才有标签
        action_tag = current_pt[2] if len(current_pt) > 2 else None
        
        # 计算误差
        dist_err = math.hypot(target_x - rob_x, target_y - rob_y)
        angle_to_target = math.atan2(target_y - rob_y, target_x - rob_x)
        yaw_err = self.normalize_angle(angle_to_target - rob_yaw)

        move_cmd = Twist()

        # === 1. 旋转任务状态 (优先级高) ===
        if self.state == "SPINNING":
            if time.time() - self.spin_start_time > self.target_spin_duration:
                self.get_logger().info("旋转完成，前往下一站。")
                self.state = "NAV"
                self.route_idx += 1
                
                # === 显式归零，确保停止旋转 ===
                move_cmd.linear.x = 0.0
                move_cmd.angular.z = 0.0
            else:
                self.get_logger().info(f"正在执行旋转... 剩余: {self.target_spin_duration - (time.time() - self.spin_start_time):.1f}s", once=True)
                move_cmd.angular.z = self.SPIN_SPEED_Z # 统一使用定义的旋转速度
            
            self.pub_cmd.publish(move_cmd)
            return

        # === 2. 到达判定 ===
        if dist_err < self.TARGET_TOLERANCE:
            # 检查是否有旋转动作 ('SPIN' 或 'SPIN_180')
            if action_tag in ['SPIN', 'SPIN_180']:
                self.get_logger().info(f"到达点 {self.route_idx+1}, 触发动作: {action_tag}")
                self.state = "SPINNING"
                self.spin_start_time = time.time()
                self.pub_cmd.publish(Twist()) # 先停稳
                
                # 根据标签设置持续时间
                if action_tag == 'SPIN_180':
                    self.target_spin_duration = self.SPIN_DURATION_180
                else:
                    self.target_spin_duration = self.SPIN_DURATION_360
            else:
                self.get_logger().info(f"到达点 {self.route_idx+1}")
                self.route_idx += 1
                self.state = "NAV"
            return

        # === 3. 全向防撞保护 ===
        is_danger, danger_cmd = self.check_omnidirectional_safety()
        if is_danger:
            self.get_logger().warn("离障碍物太近！触发紧急避让...")
            self.pub_cmd.publish(danger_cmd)
            return

        # === 4. 导航与避障状态机 ===
        if self.state == "NAV":
            # --- 模式 A: 直奔目标 ---
            min_front = self.get_scan_min_dist(-25, 25) 
            # 如果标签包含 NARROW (或 SPIN_180 在窄巷中)，可以考虑减小避障触发距离
            # 此处简单处理：如果距离障碍物过近则切到沿墙
            if min_front < self.OBSTACLE_DIST:
                self.state = "WALL_FOLLOW"
                self.obstacle_start_time = time.time()
                self.last_check_time = time.time()
                move_cmd.linear.x = 0.0
            else:
                if abs(yaw_err) > 0.4:
                    move_cmd.linear.x = 0.0
                    move_cmd.angular.z = self.TURN_SPEED * np.sign(yaw_err)
                else:
                    move_cmd.linear.x = self.MAX_SPEED
                    move_cmd.angular.z = 1.0 * yaw_err

        elif self.state == "WALL_FOLLOW":
            # --- 模式 B: 沿墙走 ---
            now = time.time()
            if now - self.last_check_time > self.CHECK_INTERVAL:
                self.last_check_time = now
                if self.check_line_of_sight(rob_yaw, angle_to_target, dist_err):
                    self.state = "NAV"
                    return 
            
            if now - self.obstacle_start_time > self.GIVE_UP_TIME:
                self.route_idx += 1
                self.state = "NAV"
                return

            d_front = self.get_scan_min_dist(-30, 30)
            d_right_front = self.get_scan_min_dist(-60, -30)
            d_right = self.get_scan_min_dist(-100, -80)
            
            if d_front < self.OBSTACLE_DIST or d_right_front < self.OBSTACLE_DIST:
                move_cmd.linear.x = 0.02
                move_cmd.angular.z = 0.7
            elif d_right < (self.WALL_DIST - 0.15):
                move_cmd.linear.x = 0.1
                move_cmd.angular.z = 0.4
            elif d_right > (self.WALL_DIST + 0.15):
                move_cmd.linear.x = 0.1
                move_cmd.angular.z = -0.4
                if d_right > 1.0: move_cmd.angular.z = -0.7
            else:
                move_cmd.linear.x = 0.15
                move_cmd.angular.z = 0.0

        self.pub_cmd.publish(move_cmd)

    # --- 辅助函数 ---
    def check_omnidirectional_safety(self):
        if self.scan_data is None: return False, Twist()
        ranges = np.array(self.scan_data.ranges)
        ranges[ranges == 0] = 999.0 
        ranges[np.isinf(ranges)] = 999.0
        min_dist = np.min(ranges)
        
        if min_dist < self.CRITICAL_DIST:
            min_idx = np.argmin(ranges)
            angle_inc = self.scan_data.angle_increment
            obs_angle = self.normalize_angle(self.scan_data.angle_min + (min_idx * angle_inc))
            cmd = Twist()
            
            if -0.78 < obs_angle < 0.78: # 前方
                cmd.linear.x = -0.15
                cmd.angular.z = -0.5 if obs_angle > 0 else 0.5
            elif obs_angle > 2.35 or obs_angle < -2.35: # 后方
                cmd.linear.x = 0.15
            else: # 侧方
                cmd.linear.x = 0.0
                cmd.angular.z = -0.8 if obs_angle > 0 else 0.8
            return True, cmd
        return False, Twist()

    def check_line_of_sight(self, current_yaw, target_angle, dist_target):
        rel_angle = self.normalize_angle(target_angle - current_yaw)
        deg_angle = math.degrees(rel_angle)
        dist_in_path = self.get_scan_min_dist(deg_angle - 10, deg_angle + 10)
        return (dist_in_path > dist_target or dist_in_path > 2.0)

    def get_scan_min_dist(self, min_deg, max_deg):
        if self.scan_data is None: return 9.9
        ranges = self.scan_data.ranges
        n = len(ranges)
        idx_min = int((min_deg if min_deg >= 0 else 360 + min_deg) / 360.0 * n) % n
        idx_max = int((max_deg if max_deg >= 0 else 360 + max_deg) / 360.0 * n) % n
        
        if idx_min < idx_max: vals = ranges[idx_min:idx_max]
        else: vals = ranges[idx_min:] + ranges[:idx_max]
        
        valid = [r for r in vals if r > 0.05 and not math.isinf(r)]
        return min(valid) if valid else 9.9

    def get_robot_pose(self):
        try:
            t = self.tf_buff.lookup_transform('map', 'base_link', rclpy.time.Time())
            x = t.transform.translation.x
            y = t.transform.translation.y
            q = t.transform.rotation
            siny = 2 * (q.w * q.z + q.x * q.y)
            cosy = 1 - 2 * (q.y * q.y + q.z * q.z)
            return x, y, math.atan2(siny, cosy)
        except: return None, None, None

    def normalize_angle(self, angle):
        while angle > math.pi: angle -= 2.0 * math.pi
        while angle < -math.pi: angle += 2.0 * math.pi
        return angle

    def stop_robot(self):
        self.pub_cmd.publish(Twist())

def main(args=None):
    rclpy.init(args=args)
    node = ManualPatrolBot()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt: pass
    finally:
        node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()
